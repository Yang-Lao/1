#include "key.h"
#include "ls1c102.h"
#include "bsp.h"

#include "src/GPIO/user_gpio.h"

uint8_t key_index[16]={0x11, 0x12, 0x14, 0x18, 0x21, 0x22, 0x24, 0x28, 0x41, 0x42, 0x44, 0x48, 0x81, 0x82, 0x84, 0x88};// ÿ�������ļ�ֵ

uint8_t key_table[16]={'1','2','3','A','4','5','6','B','7','8','9','C','+','0','-','D'};// ÿ������������

uint8_t key_value;
uint8_t passset[6];
uint8_t passin[6];
//int n=0;//�����ж��Ƿ��а�������

void key_init()
{
    gpio_init(out0, 1);
    gpio_init(out1, 1);
    gpio_init(out2, 1);
    gpio_init(out3, 1);
    gpio_init(int0, 0);
    gpio_init(int1, 0);
    gpio_init(int2, 0);
    gpio_init(int3, 0);
}

void key_write(uint8_t value)
{
    gpio_write(out0, (value & 0x01));
    gpio_write(out1, ((value>>1) & 0x01));
    gpio_write(out2, ((value>>2) & 0x01));
    gpio_write(out3, ((value>>3) & 0x01));
}

uint8_t key_read()
{
    uint8_t kvalue = 0;

    kvalue = gpio_read(int0);
    kvalue |= gpio_read(int1)<<1;
    kvalue |= gpio_read(int2)<<2;
    kvalue |= gpio_read(int3)<<3;

    return kvalue;
}

uint8_t key_scan()
{
    uint8_t value;
    int delay_time = 8;

    //��һ������
    key_write(0x01);// ���� key_write() ������Ӧ��Ϊ0001
    value = key_read();// ���� key_read() ����������ǵ�һ�У�value Ӧ��Ϊ0001
    if(value != 0)
    {
        key_write(0);
        return value | (0x01<<4);// ���� key_write() ������ key_read() �������ϲ�����0b00010001 = 0x11��
        //0b00010001 = 0x11��0b00010010 = 0x12��0b00010100 = 0x14��0b00011000 = 0x18��
    }

    delay_ms(delay_time);

    //�ڶ�������
    key_write(0x02);
    value = key_read();
    if(value != 0)
    {
        key_write(0);
        return value | (0x02<<4);
        //0b00100001 = 0x21��0b00100010 = 0x22��0b00100100 = 0x24��0b00101000 = 0x28��
    }

    delay_ms(delay_time);

    //����������
    key_write(0x04);
    value = key_read();
    if(value != 0)
    {
        key_write(0);
        return value | (0x04<<4);
        //0b01000001 = 0x41��0b01000010 = 0x42��0b01000100 = 0x44��0b01001000 = 0x48��
    }

    delay_ms(delay_time);

    //����������
    key_write(0x08);
    value = key_read();
    if(value != 0)
    {
        key_write(0);
        return value | (0x08<<4);
        //0b10000001 = 0x81��0b10000010 = 0x82��0b10000100 = 0x84��0b10001000 = 0x88��
    }

    delay_ms(delay_time);

    return 0;
}

void Password_Set(int p0,int p1,int p2,int p3,int p4,int p5)
{
    passset[0]=key_table[p0];
    passset[1]=key_table[p1];
    passset[2]=key_table[p2];
    passset[3]=key_table[p3];
    passset[4]=key_table[p4];
    passset[5]=key_table[p5];
}

void Password_In(void)
{
     int y=0;
      uint8_t key_value;
    for(;;)
    {
        delay_ms(80);
        key_value = key_scan();                //��ȡ��ֵ
        if(key_value != 0)
        {
		  printk("key_value:%x\r\n", key_value);//�����ֵ
		  for(int i = 0; i < 16; i++)
		  {
		    if(key_value == key_index[i])
            {
			    printk("key:%c\r\n", key_table[i]);//�����������
			    passin[y++]=key_table[i];
		    }
          }
        }
        if(y==6) break;
    }
}

uint8_t  Password_Judge(void)
{
    int m=0;
    for(int n=0;n<6;n++)
    {
        if(passin[n]!=key_table[3])
        {
            for(int i=0;i<6;i++)
            {
                if(passin[i]==passset[i])   m++;
            }
          break;
        }
    }
   if(m==6)   return 1;
   else if(m>0)   return 0;
}


void Password_Init(void)
{
    for (int i=0;i<6;i++)
    {
        passin[i]=key_table[3];
    }
}

void Password_Work(void)
{
    Password_In();
    delay_ms(10);

    if(Password_Judge()==0)
    {
      gpio_write(19,1);
      delay_ms(1000);
      Password_Init();
      gpio_write(19,0);
      Password_Work();
    }
    else if(Password_Judge()==1)
    {
      gpio_write(20,1);
      delay_ms(500);
      gpio_write(20,0);
      shunx(); // ˳ʱ����ת����
      delay_ms(2000);
      nix(); // ��ʱ����ת�رմ���
    }
}


